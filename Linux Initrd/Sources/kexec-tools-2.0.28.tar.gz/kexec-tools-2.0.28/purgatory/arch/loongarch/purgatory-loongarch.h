#ifndef PURGATORY_LOONGARCH_H
#define PURGATORY_LOONGARCH_H

/* nothing yet */

#endif /* PURGATORY_LOONGARCH_H */
