#include <purgatory.h>
#include "purgatory-loongarch.h"

void setup_arch(void)
{
	/* Nothing for now */
}
